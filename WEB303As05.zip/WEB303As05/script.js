/*
    Assignment 05
*/

$(document).ready(function () {
  class ContentItem {
      constructor(id, name, description, genre) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.genre = genre;
      }
      updateContentItem() {
          
      }
    }

});


